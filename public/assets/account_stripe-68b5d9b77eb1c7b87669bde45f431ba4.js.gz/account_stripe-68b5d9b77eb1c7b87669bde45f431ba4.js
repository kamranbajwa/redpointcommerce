$(document).ready(function(){


  var subscription;
  $("form").on('submit.blocker', function(e) {
    $('.refresh_box_show').show();
    e.preventDefault();
    Stripe.setPublishableKey('pk_test_89NlblSjEhYqfmvth4DbCvdf');
   return subscription.setupForm();
});

subscription = {
  setupForm: function() {
      $('input[type=submit]').attr('disabled', true);
      return subscription.processCard();
  },
  processCard: function() {
    var card;
    card = {
      number: $('#card_number').val(),
      cvc: $('#card_code').val(),
      expMonth: $('#card_month').val(),
      expYear: $('#card_year').val()
    };
     
    Stripe.createToken(card, subscription.handleStripeResponse);
  },
  handleStripeResponse: function(status, response) {
    if (status === 200) {
      $('#stripe_card_token').val(response.id)
     amt = $('#amount').val();
     $('#t_amount').val(amt);
       $("form").off("submit.blocker").trigger("submit");
       $('.refresh_box_show').hide();
    } else {
      $('.refresh_box_show').hide();
      return alert(response.error.message);
    }
  }
};
  $('.panel-heading').parents('.panel').find('.panel-body').hide();
    $('.panel-heading').addClass('panel-collapsed');
    $('.panel-heading').find('i').removeClass('fa-chevron-up').addClass('fa-chevron-down');
});
jQuery(function ($) {
$('.panel-heading').on("click", function (e) {
     $('.panel-title').text("")
    if ($(this).hasClass('panel-collapsed')) {
        $('.panel-title').text("Hide Account History")
        $(this).parents('.panel').find('.panel-body').slideDown();
        $(this).removeClass('panel-collapsed');
        $(this).find('i').removeClass('fa-chevron-down').addClass('fa-chevron-up');
    }
    else {
        $('.panel-title').text("Show Account History")
        $(this).parents('.panel').find('.panel-body').slideUp();
        $(this).addClass('panel-collapsed');
        $(this).find('i').removeClass('fa-chevron-up').addClass('fa-chevron-down');
    }
});
});
amount_before=$('#amount').val();
function handleChange(){
amount_enterd=$('#amount').val() 
if (parseInt(amount_enterd)>parseInt(amount_before)) {
  alert("sorry you can enterd more amount than "+amount_before)
  $('#amount').val(amount_before)
}
}
;
